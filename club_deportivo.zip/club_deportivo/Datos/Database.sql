create database clubdeportivodb;

create table cliente(
Npostu int,
NombreP varchar(30),
ApellidoP varchar(40),
DocP int,
TipoP varchar(50),
constraint pk_cliente primary key (Npostu)
)

select* from cliente;
INSERT INTO cliente (NombreP, ApellidoP, DocP, TipoP) VALUES ('Juan', 'Pérez', 12345678, 'Socio');
