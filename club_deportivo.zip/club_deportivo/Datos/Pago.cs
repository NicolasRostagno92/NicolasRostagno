﻿using club_deportivo.Entidades;
using MySql.Data.MySqlClient;
using System;
using System.Data;

namespace club_deportivo.Datos
{
    internal class Pago
    {
        public string Nuevo_Pago(E_Pago pago)
        {
            string? salida;
            MySqlConnection sqlCon = new MySqlConnection();

            try
            {
                sqlCon = Conexion.getInstancia().CrearConexion();

                MySqlCommand comando = new MySqlCommand("NuevoPos", sqlCon);
                comando.CommandType = CommandType.StoredProcedure;

                comando.Parameters.Add("NPo", MySqlDbType.Int32).Value = pago.NPostu;
                comando.Parameters.Add("Mon", MySqlDbType.Float).Value = pago.monto;
                comando.Parameters.Add("For", MySqlDbType.VarChar).Value = pago.formaPago;
                comando.Parameters.Add("Con", MySqlDbType.VarChar).Value = pago.concepto;

                MySqlParameter ParCodigo = new MySqlParameter();
                ParCodigo.ParameterName = "rta";
                ParCodigo.MySqlDbType = MySqlDbType.Int32;
                ParCodigo.Direction = ParameterDirection.Output;
                comando.Parameters.Add(ParCodigo);

                sqlCon.Open();
                comando.ExecuteNonQuery();
                salida = Convert.ToString(ParCodigo.Value);
            }
            catch (Exception ex)
            {
                salida = ex.Message;
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                { sqlCon.Close(); }
            }
            return salida;
        }
    }
}
