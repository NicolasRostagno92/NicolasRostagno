CREATE DEFINER=`root`@`localhost` PROCEDURE `NuevoPos`(
    IN Nom VARCHAR(30),
    IN Ape VARCHAR(40),
    IN Doc INT,
    IN Tip VARCHAR(20),
    OUT rta INT
)
BEGIN
    DECLARE filas INT DEFAULT 0;
    DECLARE existe INT DEFAULT 0;
    
    SET filas = (SELECT COUNT(*) FROM cliente);
    
    IF filas = 0 THEN
        SET filas = 452; -- Consideramos este número como el primer número de postulante
    ELSE
        -- Buscamos el último número de postulante almacenado para sumarle una unidad y
        -- considerarlo como PRIMARY KEY de la tabla
        SET filas = (SELECT MAX(NPostu) + 1 FROM cliente);
        
        -- Para saber si ya está almacenado el postulante
        SET existe = (SELECT COUNT(*) FROM cliente WHERE TipoP = Tip AND DocP = Doc);
    END IF;
    
    IF existe = 0 THEN
        INSERT INTO cliente VALUES(filas, Nom, Ape, Doc, Tip);
        SET rta = filas;
    ELSE
        SET rta = existe;
    END IF;
END