﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace club_deportivo.Entidades
{
    

    public class E_Cliente
    {
        public int NPostu { get; set; }
        public string? NombreP { get; set; }
        public string? ApellidoP { get; set; }
        public int DocP { get; set; }
        public string? TipoP { get; set; }
        public DateTime FechaInscripcion { get; set; }

        

    }
    
  
}


