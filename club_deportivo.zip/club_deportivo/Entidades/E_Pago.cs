﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace club_deportivo.Entidades
{
    internal class E_Pago
    {
      
           public int idPago { get; set; }
            public int NPostu { get; set; }
            public float monto { get; set; }
            public DateTime fecha { get; set; }
            public string? formaPago { get; set; }
            public string? concepto { get;set;}
        
    }

}

