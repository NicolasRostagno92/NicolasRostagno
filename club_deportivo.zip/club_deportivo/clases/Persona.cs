﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaClubDeportivo
{
    internal class Persona
    {
        string nombre;
        string apellido;
        int dni;
        string tipo;
        DateTime fechaInscripcion;
    

        public Persona(string nombre, string apellido, int dni,string tipo,DateTime fechaInscipcion)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.dni = dni;
            this.tipo = tipo;
            this.fechaInscripcion= fechaInscripcion;
            
        }

        public string Nombre { get => nombre; set => nombre = value; }
        public string Apellido { get => apellido; set => apellido = value; }
        public int Dni { get => dni; set => dni = value; }
        public string Tipo { get => tipo; set => tipo = value; }
        public DateTime FechaInscripcion { get => fechaInscripcion; set => fechaInscripcion = value; }

        public override string ToString()
        {
            return "Nombre: " + nombre + " -Apellido: " + apellido +  " -DNI: " + dni+ " -Tipo "+tipo;
        }
    }
}
