﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaClubDeportivo
{
    internal class Socio : Persona
    {



        public Socio(string nombre, string apellido, int dni,string tipo, DateTime fechaInscripcion) : base (nombre, apellido, dni,tipo, fechaInscripcion)
        {
            
        }

    }


  }