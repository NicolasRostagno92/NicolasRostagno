﻿namespace club_deportivo
{
    partial class frmFactura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label4 = new Label();
            lblDfecha = new Label();
            lblFPago = new Label();
            lblDia = new Label();
            label5 = new Label();
            label3 = new Label();
            label2 = new Label();
            lblValor = new Label();
            lblActividad = new Label();
            lblCliente = new Label();
            label1 = new Label();
            btnImprimir = new Button();
            btnVolver = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(label4);
            panel1.Controls.Add(lblDfecha);
            panel1.Controls.Add(lblFPago);
            panel1.Controls.Add(lblDia);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(lblValor);
            panel1.Controls.Add(lblActividad);
            panel1.Controls.Add(lblCliente);
            panel1.Location = new Point(69, 125);
            panel1.Name = "panel1";
            panel1.Size = new Size(880, 412);
            panel1.TabIndex = 0;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(611, 370);
            label4.Name = "label4";
            label4.Size = new Size(87, 21);
            label4.TabIndex = 2;
            label4.Text = "MONTO: $";
            // 
            // lblDfecha
            // 
            lblDfecha.AutoSize = true;
            lblDfecha.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblDfecha.Location = new Point(611, 30);
            lblDfecha.Name = "lblDfecha";
            lblDfecha.Size = new Size(130, 21);
            lblDfecha.TabIndex = 2;
            lblDfecha.Text = "fechaDeIngreso";
            // 
            // lblFPago
            // 
            lblFPago.AutoSize = true;
            lblFPago.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblFPago.Location = new Point(418, 337);
            lblFPago.Name = "lblFPago";
            lblFPago.Size = new Size(107, 21);
            lblFPago.TabIndex = 2;
            lblFPago.Text = "formDePago";
            // 
            // lblDia
            // 
            lblDia.AutoSize = true;
            lblDia.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblDia.Location = new Point(418, 257);
            lblDia.Name = "lblDia";
            lblDia.Size = new Size(34, 21);
            lblDia.TabIndex = 2;
            lblDia.Text = "dia";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(76, 336);
            label5.Name = "label5";
            label5.Size = new Size(142, 21);
            label5.TabIndex = 2;
            label5.Text = "FORMA DE PAGO:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(75, 256);
            label3.Name = "label3";
            label3.Size = new Size(162, 21);
            label3.TabIndex = 2;
            label3.Text = "FECHA DE INGRESO:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(75, 180);
            label2.Name = "label2";
            label2.Size = new Size(235, 21);
            label2.TabIndex = 2;
            label2.Text = "SE INSCRIBE A LA ACTIVIDAD:";
            // 
            // lblValor
            // 
            lblValor.AutoSize = true;
            lblValor.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblValor.Location = new Point(720, 370);
            lblValor.Name = "lblValor";
            lblValor.Size = new Size(64, 21);
            lblValor.TabIndex = 2;
            lblValor.Text = "$$$$$$";
            // 
            // lblActividad
            // 
            lblActividad.AutoSize = true;
            lblActividad.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblActividad.Location = new Point(417, 180);
            lblActividad.Name = "lblActividad";
            lblActividad.Size = new Size(83, 21);
            lblActividad.TabIndex = 2;
            lblActividad.Text = "Actividad";
            // 
            // lblCliente
            // 
            lblCliente.AutoSize = true;
            lblCliente.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblCliente.Location = new Point(76, 92);
            lblCliente.Name = "lblCliente";
            lblCliente.Size = new Size(64, 21);
            lblCliente.TabIndex = 2;
            lblCliente.Text = "Cliente";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(197, 42);
            label1.Name = "label1";
            label1.Size = new Size(645, 45);
            label1.TabIndex = 0;
            label1.Text = "SISTEMA CLUB COMPROBANTE DE PAGO";
            // 
            // btnImprimir
            // 
            btnImprimir.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnImprimir.Location = new Point(698, 558);
            btnImprimir.Name = "btnImprimir";
            btnImprimir.Size = new Size(112, 32);
            btnImprimir.TabIndex = 1;
            btnImprimir.Text = "IMPRIMIR";
            btnImprimir.UseVisualStyleBackColor = true;
            // 
            // btnVolver
            // 
            btnVolver.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnVolver.Location = new Point(849, 558);
            btnVolver.Name = "btnVolver";
            btnVolver.Size = new Size(100, 30);
            btnVolver.TabIndex = 2;
            btnVolver.Text = "VOLVER";
            btnVolver.UseVisualStyleBackColor = true;
            btnVolver.Click += btnVolver_Click;
            // 
            // frmFactura
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1032, 617);
            Controls.Add(btnVolver);
            Controls.Add(btnImprimir);
            Controls.Add(label1);
            Controls.Add(panel1);
            Name = "frmFactura";
            Text = "COMPROBANTE PAGO";
            Load += frmFactura_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Button btnImprimir;
        private Label lblCliente;
        private Label lblDfecha;
        private Label label3;
        private Label label2;
        private Label lblActividad;
        private Label label4;
        private Label lblDia;
        private Label lblValor;
        private Label lblFPago;
        private Label label5;
        private Button btnVolver;
    }
}