﻿namespace club_deportivo
{
    partial class frmGrilla
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            eClienteBindingSource1 = new BindingSource(components);
            eClienteBindingSource2 = new BindingSource(components);
            btnVolver = new Button();
            eClienteBindingSource = new BindingSource(components);
            conexionBindingSource = new BindingSource(components);
            dtgvCliente = new DataGridView();
            conexionBindingSource1 = new BindingSource(components);
            ((System.ComponentModel.ISupportInitialize)eClienteBindingSource1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)eClienteBindingSource2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)eClienteBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)conexionBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dtgvCliente).BeginInit();
            ((System.ComponentModel.ISupportInitialize)conexionBindingSource1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(314, 32);
            label1.Name = "label1";
            label1.Size = new Size(438, 45);
            label1.TabIndex = 0;
            label1.Text = "CLUB DEPORTIVO CLIENTES";
            // 
            // eClienteBindingSource1
            // 
            eClienteBindingSource1.DataSource = typeof(Entidades.E_Cliente);
            // 
            // eClienteBindingSource2
            // 
            eClienteBindingSource2.DataSource = typeof(Entidades.E_Cliente);
            // 
            // btnVolver
            // 
            btnVolver.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnVolver.Location = new Point(963, 549);
            btnVolver.Name = "btnVolver";
            btnVolver.Size = new Size(98, 34);
            btnVolver.TabIndex = 2;
            btnVolver.Text = "VOLVER";
            btnVolver.UseVisualStyleBackColor = true;
            btnVolver.Click += btnVolver_Click;
            // 
            // eClienteBindingSource
            // 
            eClienteBindingSource.DataSource = typeof(Entidades.E_Cliente);
            eClienteBindingSource.CurrentChanged += eClienteBindingSource_CurrentChanged;
            // 
            // conexionBindingSource
            // 
            conexionBindingSource.DataSource = typeof(Datos.Conexion);
            // 
            // dtgvCliente
            // 
            dtgvCliente.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvCliente.Location = new Point(0, 93);
            dtgvCliente.Name = "dtgvCliente";
            dtgvCliente.RowTemplate.Height = 25;
            dtgvCliente.Size = new Size(1114, 512);
            dtgvCliente.TabIndex = 1;
            dtgvCliente.CellContentClick += dataGridView1_CellContentClick;
            // 
            // conexionBindingSource1
            // 
            conexionBindingSource1.DataSource = typeof(Datos.Conexion);
            // 
            // frmGrilla
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1114, 605);
            Controls.Add(btnVolver);
            Controls.Add(dtgvCliente);
            Controls.Add(label1);
            Name = "frmGrilla";
            Text = "CLIENTES";
            Load += frmGrilla_Load_1;
            ((System.ComponentModel.ISupportInitialize)eClienteBindingSource1).EndInit();
            ((System.ComponentModel.ISupportInitialize)eClienteBindingSource2).EndInit();
            ((System.ComponentModel.ISupportInitialize)eClienteBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)conexionBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)dtgvCliente).EndInit();
            ((System.ComponentModel.ISupportInitialize)conexionBindingSource1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private DataGridView dataGridView1;
        private Button btnVolver;
        private BindingSource eClienteBindingSource1;
        private BindingSource eClienteBindingSource;
        private BindingSource conexionBindingSource;
        private BindingSource eClienteBindingSource2;
        private DataGridViewTextBoxColumn nPostuDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn nombrePDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn apellidoPDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn docPDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn tipoPDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn NPostu;
        private DataGridViewTextBoxColumn NombreP;
        private DataGridViewTextBoxColumn ApellidoP;
        private DataGridViewTextBoxColumn DocP;
        private DataGridViewTextBoxColumn TipoP;
        private BindingSource conexionBindingSource1;
    }
}