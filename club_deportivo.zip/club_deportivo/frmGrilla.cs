﻿using club_deportivo.Datos;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace club_deportivo
{
    public partial class frmGrilla : Form
    {

        DataGridView dtgvCliente = new DataGridView();

        public frmGrilla()
        {
            InitializeComponent();
            dtgvCliente.Columns.Add("NPostu", "Número de Postulante");
            dtgvCliente.Columns.Add("NombreP", "Nombre");
            dtgvCliente.Columns.Add("ApellidoP", "Apellido");
            dtgvCliente.Columns.Add("DocP", "Documento");
            dtgvCliente.Columns.Add("TipoP", "Tipo");
            dtgvCliente.Columns.Add("FechaInscripcion", "Fecha de Inscripción");
            // Establecer propiedades para mostrar correctamente

        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            frmPrincipal principal = new frmPrincipal();
            principal.Show();
            this.Hide();
        }


        private void frmGrilla_Load_1(object sender, EventArgs e)
        {

            CargarGrilla();


        }
        public void CargarGrilla()
        {
            MySqlConnection sqlCon = new MySqlConnection();
            try
            {
                string query;
                sqlCon = Conexion.getInstancia().CrearConexion();
                query = "select * from cliente; ";

                MySqlCommand comando = new MySqlCommand(query, sqlCon);
                comando.CommandType = CommandType.Text;
                sqlCon.Open();

                MySqlDataReader reader;
                reader = comando.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        int renglon = dtgvCliente.Rows.Add();
                        dtgvCliente.Rows[renglon].Cells["NPostu"].Value = reader.GetInt32(0);
                        dtgvCliente.Rows[renglon].Cells["NombreP"].Value = reader.GetString(1);
                        dtgvCliente.Rows[renglon].Cells["ApellidoP"].Value = reader.GetString(2);
                        dtgvCliente.Rows[renglon].Cells["DocP"].Value = reader.GetInt32(3);
                        dtgvCliente.Rows[renglon].Cells["TipoP"].Value = reader.GetString(4);

                        // Convertir el valor de la columna FechaInscripcion a DateTime
                        DateTime fechaInscripcion = reader.GetDateTime(5);

                        // Asignar la fecha formateada a la celda
                        dtgvCliente.Rows[renglon].Cells["FechaInscripcion"].Value = fechaInscripcion.ToString("yyyy-MM-dd");
                    }
                  

                }
                else
                {
                    MessageBox.Show("NO HAY DATOS PARA LA CARGA DE LA GRILLA");
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                { sqlCon.Close(); };
            }

        }
        private void btnVolver_Click(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void eClienteBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }
    }
}
    


