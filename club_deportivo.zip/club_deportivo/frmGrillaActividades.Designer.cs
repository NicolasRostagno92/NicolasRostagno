﻿namespace club_deportivo
{
    partial class frmGrillaActividades
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            dtgvActividades = new DataGridView();
            NActividad = new DataGridViewTextBoxColumn();
            Nombre = new DataGridViewTextBoxColumn();
            Precio = new DataGridViewTextBoxColumn();
            btnCargar = new Button();
            btnBorrar = new Button();
            label2 = new Label();
            label3 = new Label();
            txtNombre = new TextBox();
            txtPrecio = new TextBox();
            btnVolver = new Button();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dtgvActividades).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(290, 47);
            label1.Name = "label1";
            label1.Size = new Size(505, 45);
            label1.TabIndex = 0;
            label1.Text = "CLUB DEPORTIVO ACTIVIDADES";
            // 
            // dtgvActividades
            // 
            dtgvActividades.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvActividades.Columns.AddRange(new DataGridViewColumn[] { NActividad, Nombre, Precio });
            dtgvActividades.Location = new Point(12, 271);
            dtgvActividades.Name = "dtgvActividades";
            dtgvActividades.RowTemplate.Height = 25;
            dtgvActividades.Size = new Size(997, 272);
            dtgvActividades.TabIndex = 1;
            dtgvActividades.CellContentClick += dtgvActividades_CellContentClick;
            // 
            // NActividad
            // 
            NActividad.HeaderText = "ID Actividad";
            NActividad.Name = "NActividad";
            // 
            // Nombre
            // 
            Nombre.HeaderText = "Actividad";
            Nombre.Name = "Nombre";
            // 
            // Precio
            // 
            Precio.HeaderText = "Precio";
            Precio.Name = "Precio";
            // 
            // btnCargar
            // 
            btnCargar.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnCargar.Location = new Point(687, 120);
            btnCargar.Name = "btnCargar";
            btnCargar.Size = new Size(156, 43);
            btnCargar.TabIndex = 2;
            btnCargar.Text = "CARGAR";
            btnCargar.UseVisualStyleBackColor = true;
            btnCargar.Click += btnCargar_Click;
            // 
            // btnBorrar
            // 
            btnBorrar.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnBorrar.Location = new Point(687, 204);
            btnBorrar.Name = "btnBorrar";
            btnBorrar.Size = new Size(156, 43);
            btnBorrar.TabIndex = 2;
            btnBorrar.Text = "BORRAR";
            btnBorrar.UseVisualStyleBackColor = true;
            btnBorrar.Click += btnBorrar_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(71, 131);
            label2.Name = "label2";
            label2.Size = new Size(173, 21);
            label2.TabIndex = 3;
            label2.Text = "NOMBRE ACTIVIDAD:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(72, 205);
            label3.Name = "label3";
            label3.Size = new Size(70, 21);
            label3.TabIndex = 4;
            label3.Text = "PRECIO:";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(291, 130);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(222, 23);
            txtNombre.TabIndex = 5;
            // 
            // txtPrecio
            // 
            txtPrecio.Location = new Point(290, 203);
            txtPrecio.Name = "txtPrecio";
            txtPrecio.Size = new Size(222, 23);
            txtPrecio.TabIndex = 5;
            // 
            // btnVolver
            // 
            btnVolver.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnVolver.Location = new Point(873, 562);
            btnVolver.Name = "btnVolver";
            btnVolver.Size = new Size(136, 43);
            btnVolver.TabIndex = 2;
            btnVolver.Text = "VOLVER";
            btnVolver.UseVisualStyleBackColor = true;
            btnVolver.Click += btnVolver_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(405, 562);
            button1.Name = "button1";
            button1.Size = new Size(214, 43);
            button1.TabIndex = 2;
            button1.Text = "LISTA ACTIVIDADES";
            button1.UseVisualStyleBackColor = true;
            button1.Click += btnListaDeActividades_Click;
            // 
            // frmGrillaActividades
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1040, 617);
            Controls.Add(txtPrecio);
            Controls.Add(txtNombre);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(btnBorrar);
            Controls.Add(btnVolver);
            Controls.Add(button1);
            Controls.Add(btnCargar);
            Controls.Add(dtgvActividades);
            Controls.Add(label1);
            Name = "frmGrillaActividades";
            Text = "Actividades del Club";
            Load += frmGrillaActividades_Load;
            ((System.ComponentModel.ISupportInitialize)dtgvActividades).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private DataGridView dtgvActividades;
        private Button btnCargar;
        private Button btnBorrar;
        private Label label2;
        private Label label3;
        private TextBox txtNombre;
        private TextBox txtPrecio;
        private DataGridViewTextBoxColumn NActividad;
        private DataGridViewTextBoxColumn Nombre;
        private DataGridViewTextBoxColumn Precio;
        private Button btnVolver;
        private Button button1;
    }
}