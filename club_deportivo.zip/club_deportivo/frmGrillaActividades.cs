﻿using club_deportivo.Datos;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace club_deportivo
{
    public partial class frmGrillaActividades : Form
    {
        int nro; // variable que se usan para cualquier procedimiento de este formulario

        public frmGrillaActividades()
        {
            InitializeComponent();
        }

        private void btnCargar_Click(object sender, EventArgs e)
        {
            // Agregar un renglon para la escritura
            int renglon = dtgvActividades.Rows.Add();
            // colocamos los datos en las columnas de esa fila
            dtgvActividades.Rows[renglon].Cells[0].Value = "";
            dtgvActividades.Rows[renglon].Cells[1].Value = txtNombre.Text;
            dtgvActividades.Rows[renglon].Cells[2].Value = txtPrecio.Text;

            // Insertar en la base de datos
            InsertarActividad(txtNombre.Text, txtPrecio.Text);
            // blanqueo de los textBoxS
            txtNombre.Text = "";
            txtPrecio.Text = "";
            // el foco se instala en el objeto
            txtNombre.Focus();
        }


        private void InsertarActividad(string nombre, string precio)
        {
            MySqlConnection sqlCon = new MySqlConnection();

            try
            {
                sqlCon = Conexion.getInstancia().CrearConexion();
                string query = "INSERT INTO Actividades (Nombre, Precio) VALUES (@Nombre, @Precio);";
                MySqlCommand comando = new MySqlCommand(query, sqlCon);
                comando.Parameters.AddWithValue("@Nombre", nombre);
                comando.Parameters.AddWithValue("@Precio", precio);

                sqlCon.Open();
                comando.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al insertar en la base de datos: " + ex.Message);
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
            }
        }


        private void dtgvActividades_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            nro = e.RowIndex; // muestra la posición de la fila seleccionada
            if (nro != -1)
            {
                MessageBox.Show((string)dtgvActividades.Rows[nro].Cells
                [1].Value);
            }
            else
            {
                MessageBox.Show("selecciono el ENCABEZADO");
            }
        }
        private void btnBorrar_Click(object sender, EventArgs e)
        {
            dtgvActividades.Rows.RemoveAt(nro);
        }

        private void frmGrillaActividades_Load(object sender, EventArgs e)
        {

        }

        private void dtgvActividades_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            frmPrincipal principal = new frmPrincipal();
            principal.Show();
            this.Hide();
        }

        private void btnListaDeActividades_Click(object sender, EventArgs e)
        {
            CargarDatosEnGrilla();
        }
        private void CargarDatosEnGrilla()
        {
            MySqlConnection sqlCon = new MySqlConnection();

            try
            {
                sqlCon = Conexion.getInstancia().CrearConexion();
                string query = "SELECT * FROM Actividades;";
                MySqlCommand comando = new MySqlCommand(query, sqlCon);

                DataTable dataTable = new DataTable();
                MySqlDataAdapter dataAdapter = new MySqlDataAdapter(comando);
                dataAdapter.Fill(dataTable);

                dtgvActividades.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar datos en la grilla: " + ex.Message);
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
            }
        }
    }
}
