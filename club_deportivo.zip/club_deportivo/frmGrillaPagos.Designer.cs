﻿namespace club_deportivo
{
    partial class frmGrillaPagos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgtvPagos = new DataGridView();
            txtVolver = new Button();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgtvPagos).BeginInit();
            SuspendLayout();
            // 
            // dgtvPagos
            // 
            dgtvPagos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgtvPagos.Location = new Point(34, 135);
            dgtvPagos.Name = "dgtvPagos";
            dgtvPagos.RowTemplate.Height = 25;
            dgtvPagos.Size = new Size(922, 405);
            dgtvPagos.TabIndex = 0;
            dgtvPagos.CellContentClick += dgtvPagos_CellContentClick;
            // 
            // txtVolver
            // 
            txtVolver.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            txtVolver.Location = new Point(850, 546);
            txtVolver.Name = "txtVolver";
            txtVolver.Size = new Size(106, 45);
            txtVolver.TabIndex = 1;
            txtVolver.Text = "VOLVER";
            txtVolver.UseVisualStyleBackColor = true;
            txtVolver.Click += txtVolver_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(343, 54);
            label1.Name = "label1";
            label1.Size = new Size(361, 40);
            label1.TabIndex = 2;
            label1.Text = "CLUB DEPORTIVO PAGOS";
            // 
            // frmGrillaPagos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1036, 603);
            Controls.Add(label1);
            Controls.Add(txtVolver);
            Controls.Add(dgtvPagos);
            Name = "frmGrillaPagos";
            Text = "LISTA DE PAGOS";
            Load += frmGrillaPagos_Load;
            ((System.ComponentModel.ISupportInitialize)dgtvPagos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgtvPagos;
        private Button txtVolver;
        private Label label1;
    }
}