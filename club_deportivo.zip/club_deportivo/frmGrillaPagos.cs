﻿using club_deportivo.Datos;
using MySql.Data.MySqlClient;
using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;

namespace club_deportivo
{
    public partial class frmGrillaPagos : Form
    {
        

        public frmGrillaPagos()
        {
            InitializeComponent();

            dgtvPagos.Columns.Add("IdPago", "Id de Pago");
            dgtvPagos.Columns.Add("NPostu", "Numero de Cliente");
            dgtvPagos.Columns.Add("monto", "Monto pago");
            dgtvPagos.Columns.Add("fecha", "Fecha de pago");
            dgtvPagos.Columns.Add("formaPago", "Tipo de pago");
            dgtvPagos.Columns.Add("concepto", "Concepto");
          

            // Establecer propiedades para mostrar correctamente
        }

        private void frmGrillaPagos_Load(object sender, EventArgs e)
        {
            CargarDatosEnGrilla();
        }

        private void CargarDatosEnGrilla()
        {
            MySqlConnection sqlCon = new MySqlConnection();
            try
            {
                string query;
                sqlCon = Conexion.getInstancia().CrearConexion();
                query = "select * from pago; ";

                MySqlCommand comando = new MySqlCommand(query, sqlCon);
                comando.CommandType = CommandType.Text;
                sqlCon.Open();

                MySqlDataReader reader;
                reader = comando.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {

                    
                        int renglon = dgtvPagos.Rows.Add();
                        dgtvPagos.Rows[renglon].Cells["idPago"].Value = reader.GetInt32(0);
                        dgtvPagos.Rows[renglon].Cells["NPostu"].Value = reader.GetInt32(1);
                        dgtvPagos.Rows[renglon].Cells["monto"].Value = reader.GetFloat(2);
                        // Convertir el valor de la columna FechaInscripcion a DateTime
                        DateTime fechaInscripcion = reader.GetDateTime(3);
                        // Asignar la fecha formateada a la celda
                        dgtvPagos.Rows[renglon].Cells["fecha"].Value = fechaInscripcion.ToString("yyyy-MM-dd");
                        dgtvPagos.Rows[renglon].Cells["formaPago"].Value = reader.GetString(4);
                        dgtvPagos.Rows[renglon].Cells["concepto"].Value = reader.GetString(5);

                    }


                }
                else
                {
                    MessageBox.Show("NO HAY DATOS PARA LA CARGA DE LA GRILLA");
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                { sqlCon.Close(); };
            }
        }
        private void txtVolver_Click(object sender, EventArgs e)
        {
            frmPagar pagos = new frmPagar();
            pagos.Show();
            this.Hide();
        }

        private void dgtvPagos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
