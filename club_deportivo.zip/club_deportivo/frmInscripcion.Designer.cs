﻿namespace club_deportivo
{
    partial class frmInscripcion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnVolver = new Button();
            label2 = new Label();
            txtApellido = new TextBox();
            txtDNI = new TextBox();
            txtTipo = new TextBox();
            lblApellido = new Label();
            btnInscribir = new Button();
            lblNombre = new Label();
            label1 = new Label();
            label3 = new Label();
            btnLimpiar = new Button();
            lblDNI = new Label();
            txtNombre = new TextBox();
            pictureBox1 = new PictureBox();
            groupBox1 = new GroupBox();
            btnListaSocios = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // btnVolver
            // 
            btnVolver.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnVolver.Location = new Point(892, 562);
            btnVolver.Name = "btnVolver";
            btnVolver.Size = new Size(94, 29);
            btnVolver.TabIndex = 8;
            btnVolver.Text = "VOLVER";
            btnVolver.UseVisualStyleBackColor = true;
            btnVolver.Click += btnVolver_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Black", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(307, 42);
            label2.Name = "label2";
            label2.Size = new Size(435, 45);
            label2.TabIndex = 0;
            label2.Text = "CLUB DEPORTIVO FITNESS";
            // 
            // txtApellido
            // 
            txtApellido.Location = new Point(593, 154);
            txtApellido.Name = "txtApellido";
            txtApellido.Size = new Size(233, 29);
            txtApellido.TabIndex = 7;
            // 
            // txtDNI
            // 
            txtDNI.Location = new Point(593, 226);
            txtDNI.Name = "txtDNI";
            txtDNI.Size = new Size(233, 29);
            txtDNI.TabIndex = 5;
            // 
            // txtTipo
            // 
            txtTipo.Location = new Point(593, 290);
            txtTipo.Name = "txtTipo";
            txtTipo.Size = new Size(233, 29);
            txtTipo.TabIndex = 5;
            // 
            // lblApellido
            // 
            lblApellido.AutoSize = true;
            lblApellido.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblApellido.Location = new Point(357, 154);
            lblApellido.Name = "lblApellido";
            lblApellido.Size = new Size(85, 21);
            lblApellido.TabIndex = 1;
            lblApellido.Text = "APELLIDO";
            // 
            // btnInscribir
            // 
            btnInscribir.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnInscribir.Location = new Point(357, 373);
            btnInscribir.Name = "btnInscribir";
            btnInscribir.Size = new Size(105, 37);
            btnInscribir.TabIndex = 9;
            btnInscribir.Text = "INSCRIBIR";
            btnInscribir.UseVisualStyleBackColor = true;
            btnInscribir.Click += btnInscribir_Click;
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblNombre.Location = new Point(357, 89);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(79, 21);
            lblNombre.TabIndex = 0;
            lblNombre.Text = "NOMBRE";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(357, 226);
            label1.Name = "label1";
            label1.Size = new Size(40, 21);
            label1.TabIndex = 0;
            label1.Text = "DNI";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(357, 290);
            label3.Name = "label3";
            label3.Size = new Size(46, 21);
            label3.TabIndex = 0;
            label3.Text = "TIPO";
            // 
            // btnLimpiar
            // 
            btnLimpiar.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnLimpiar.Location = new Point(564, 373);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(97, 37);
            btnLimpiar.TabIndex = 10;
            btnLimpiar.Text = "LIMPIAR";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // lblDNI
            // 
            lblDNI.AutoSize = true;
            lblDNI.Location = new Point(114, -109);
            lblDNI.Name = "lblDNI";
            lblDNI.Size = new Size(40, 21);
            lblDNI.TabIndex = 3;
            lblDNI.Text = "DNI";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(593, 89);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(233, 29);
            txtNombre.TabIndex = 4;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources._87433272_muscular_atlético_deportista_brazo_sosteniendo_pesas_de_pesas_de_disco_y_compuesto_con_cadena_de;
            pictureBox1.Location = new Point(0, 28);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(313, 411);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(pictureBox1);
            groupBox1.Controls.Add(txtNombre);
            groupBox1.Controls.Add(lblDNI);
            groupBox1.Controls.Add(btnListaSocios);
            groupBox1.Controls.Add(btnLimpiar);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(lblNombre);
            groupBox1.Controls.Add(btnInscribir);
            groupBox1.Controls.Add(lblApellido);
            groupBox1.Controls.Add(txtTipo);
            groupBox1.Controls.Add(txtDNI);
            groupBox1.Controls.Add(txtApellido);
            groupBox1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(67, 104);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(919, 439);
            groupBox1.TabIndex = 11;
            groupBox1.TabStop = false;
            groupBox1.Text = "INSCRIBIR CLIENTES:";
            // 
            // btnListaSocios
            // 
            btnListaSocios.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnListaSocios.Location = new Point(751, 373);
            btnListaSocios.Name = "btnListaSocios";
            btnListaSocios.Size = new Size(135, 37);
            btnListaSocios.TabIndex = 10;
            btnListaSocios.Text = "LISTA SOCIOS";
            btnListaSocios.UseVisualStyleBackColor = true;
            btnListaSocios.Click += btnListaSocios_Click;
            // 
            // frmInscripcion
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1038, 603);
            Controls.Add(groupBox1);
            Controls.Add(btnVolver);
            Controls.Add(label2);
            Name = "frmInscripcion";
            Text = "frmInscripcion";
            Load += frmInscripcion_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnVolver;
        private Label label2;
        private Button btnListaSocios;
        private TextBox txtApellido;
        private TextBox txtDNI;
        private TextBox txtTipo;
        private Label lblApellido;
        private Button btnInscribir;
        private Label lblNombre;
        private Label label1;
        private Label label3;
        private Button btnLimpiar;
        private Label lblDNI;
        private TextBox txtNombre;
        private PictureBox pictureBox1;
        private GroupBox groupBox1;
        
    }
}