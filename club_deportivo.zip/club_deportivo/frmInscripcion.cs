﻿using club_deportivo.Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace club_deportivo
{
    public partial class frmInscripcion : Form
    {
        public frmInscripcion()
        {
            InitializeComponent();
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            frmPrincipal principal = new frmPrincipal();
            principal.Show();
            this.Hide();
        }
        private void btnInscribir_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text == "" || txtDNI.Text == "" ||
            txtApellido.Text == "" || txtTipo.Text == "")
            {
                MessageBox.Show("Debe completar datos requeridos (*) ",
                "AVISO DEL SISTEMA", MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            }
            else
            {
                string respuesta;
                E_Cliente Usu = new E_Cliente();
                Usu.NombreP = txtNombre.Text;
                Usu.ApellidoP = txtApellido.Text;
                Usu.DocP = Convert.ToInt32(txtDNI.Text);
                Usu.TipoP = txtTipo.Text;
               



                Usu.FechaInscripcion = DateTime.Now.Date;

                // instanciamos para usar el metodo dentro de postulantes
                Datos.Cliente cliente = new Datos.Cliente();
                respuesta = cliente.Nuevo_Postu(Usu);

                bool esnumero = int.TryParse(respuesta, out int codigo);
                if (esnumero)
                {
                    if (codigo == 1)
                    {
                        MessageBox.Show("POSTULANTE YA EXISTE", "AVISO DELSISTEMA",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show("se almaceno con exito con el codigo Nro " + respuesta, "AVISO DEL SISTEMA",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Question);
                    }
                }
            }
        }
        /* ===================================================
        * Limpiamos los objetos para un nuevo ingreso
        * ================================================ */
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNombre.Text = "";
            txtDNI.Text = "";
            txtApellido.Text = "";
            txtTipo.Text = "";
            txtNombre.Focus();
        }

        private void frmInscripcion_Load(object sender, EventArgs e)
        {

        }

        private void btnListaSocios_Click(object sender, EventArgs e)
        {
            frmGrilla grilla = new frmGrilla();
            grilla.Show();
            this.Close();
;       }
    }

}
