﻿namespace club_deportivo
{
    partial class frmPagar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            groupBox1 = new GroupBox();
            groupBox3 = new GroupBox();
            radioButton2 = new RadioButton();
            optEf = new RadioButton();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            btnVolver = new Button();
            btnComprobante = new Button();
            btnPagar = new Button();
            txtConcepto = new TextBox();
            txtMonto = new TextBox();
            txtIdCliente = new TextBox();
            optTarj = new RadioButton();
            optEfvo = new RadioButton();
            btnListaPagos = new Button();
            groupBox1.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(343, 34);
            label1.Name = "label1";
            label1.Size = new Size(321, 40);
            label1.TabIndex = 0;
            label1.Text = "SISTEMA CLUB PAGOS";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnListaPagos);
            groupBox1.Controls.Add(groupBox3);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(btnComprobante);
            groupBox1.Controls.Add(btnPagar);
            groupBox1.Controls.Add(txtConcepto);
            groupBox1.Controls.Add(txtMonto);
            groupBox1.Controls.Add(txtIdCliente);
            groupBox1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(59, 103);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(874, 426);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "INGRESE NÚMERO DE CLIENTE:";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(radioButton2);
            groupBox3.Controls.Add(optEf);
            groupBox3.Location = new Point(551, 67);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(276, 215);
            groupBox3.TabIndex = 5;
            groupBox3.TabStop = false;
            groupBox3.Text = "FORMA DE PAGO";
            groupBox3.Enter += groupBox3_Enter;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(71, 140);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(92, 25);
            radioButton2.TabIndex = 2;
            radioButton2.TabStop = true;
            radioButton2.Text = "TARJETA";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += optTarj_CheckedChanged;
            // 
            // optEf
            // 
            optEf.AutoSize = true;
            optEf.Location = new Point(71, 69);
            optEf.Name = "optEf";
            optEf.Size = new Size(101, 25);
            optEf.TabIndex = 2;
            optEf.TabStop = true;
            optEf.Text = "EFECTIVO";
            optEf.UseVisualStyleBackColor = true;
            optEf.CheckedChanged += optEfvo_CheckedChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(56, 253);
            label4.Name = "label4";
            label4.Size = new Size(94, 21);
            label4.TabIndex = 3;
            label4.Text = "CONCEPTO";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(56, 159);
            label3.Name = "label3";
            label3.Size = new Size(70, 21);
            label3.TabIndex = 3;
            label3.Text = "MONTO";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(56, 75);
            label2.Name = "label2";
            label2.Size = new Size(119, 21);
            label2.TabIndex = 3;
            label2.Text = "ID DE CLIENTE";
            // 
            // btnVolver
            // 
            btnVolver.Location = new Point(807, 547);
            btnVolver.Name = "btnVolver";
            btnVolver.Size = new Size(102, 40);
            btnVolver.TabIndex = 2;
            btnVolver.Text = "VOLVER";
            btnVolver.UseVisualStyleBackColor = true;
            btnVolver.Click += btnVolver_Click;
            // 
            // btnComprobante
            // 
            btnComprobante.Location = new Point(302, 315);
            btnComprobante.Name = "btnComprobante";
            btnComprobante.Size = new Size(187, 57);
            btnComprobante.TabIndex = 2;
            btnComprobante.Text = "COMPROBANTE";
            btnComprobante.UseVisualStyleBackColor = true;
            btnComprobante.Click += btnComprobante_Click;
            // 
            // btnPagar
            // 
            btnPagar.Location = new Point(56, 315);
            btnPagar.Name = "btnPagar";
            btnPagar.Size = new Size(187, 57);
            btnPagar.TabIndex = 2;
            btnPagar.Text = "PAGAR";
            btnPagar.UseVisualStyleBackColor = true;
            btnPagar.Click += btnPagar_Click;
            // 
            // txtConcepto
            // 
            txtConcepto.Location = new Point(293, 253);
            txtConcepto.Name = "txtConcepto";
            txtConcepto.Size = new Size(196, 29);
            txtConcepto.TabIndex = 0;
            txtConcepto.TextChanged += txtConcepto_TextChanged;
            // 
            // txtMonto
            // 
            txtMonto.Location = new Point(293, 159);
            txtMonto.Name = "txtMonto";
            txtMonto.Size = new Size(196, 29);
            txtMonto.TabIndex = 0;
            txtMonto.TextChanged += txtMonto_TextChanged;
            // 
            // txtIdCliente
            // 
            txtIdCliente.Location = new Point(293, 67);
            txtIdCliente.Name = "txtIdCliente";
            txtIdCliente.Size = new Size(196, 29);
            txtIdCliente.TabIndex = 0;
            txtIdCliente.TextChanged += txtIdCliente_TextChanged;
            // 
            // optTarj
            // 
            optTarj.AutoSize = true;
            optTarj.Location = new Point(64, 159);
            optTarj.Name = "optTarj";
            optTarj.Size = new Size(92, 25);
            optTarj.TabIndex = 3;
            optTarj.TabStop = true;
            optTarj.Text = "TARJETA";
            optTarj.UseVisualStyleBackColor = true;
            optTarj.CheckedChanged += optTarj_CheckedChanged;
            // 
            // optEfvo
            // 
            optEfvo.AutoSize = true;
            optEfvo.Location = new Point(63, 88);
            optEfvo.Name = "optEfvo";
            optEfvo.Size = new Size(101, 25);
            optEfvo.TabIndex = 3;
            optEfvo.TabStop = true;
            optEfvo.Text = "EFECTIVO";
            optEfvo.UseVisualStyleBackColor = true;
            optEfvo.CheckedChanged += optEfvo_CheckedChanged;
            // 
            // btnListaPagos
            // 
            btnListaPagos.Location = new Point(565, 315);
            btnListaPagos.Name = "btnListaPagos";
            btnListaPagos.Size = new Size(196, 57);
            btnListaPagos.TabIndex = 6;
            btnListaPagos.Text = "LISTA DE PAGOS";
            btnListaPagos.UseVisualStyleBackColor = true;
            btnListaPagos.Click += btnListaPagos_Click;
            // 
            // frmPagar
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1023, 614);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Controls.Add(btnVolver);
            Name = "frmPagar";
            Text = "PAGOS CLUB";
            Load += frmPagar_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private GroupBox groupBox1;
        private Button btnVolver;
        private Button btnComprobante;
        private Button btnPagar;
        private TextBox txtIdCliente;
        private RadioButton optTarj;
        private RadioButton optEfvo;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox txtConcepto;
        private TextBox txtMonto;
        private GroupBox groupBox3;
        private RadioButton radioButton2;
        private RadioButton optEf;
        private Button btnListaPagos;
    }
}