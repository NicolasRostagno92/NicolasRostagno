﻿using club_deportivo;
using club_deportivo.Datos;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace club_deportivo
{
    public partial class frmPagar : Form
    {
        public frmFactura doc = new frmFactura();

        public frmPagar()
        {
            InitializeComponent();
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            frmPrincipal principal = new frmPrincipal();
            principal.Show();
            this.Hide();
        }

        private void btnComprobante_Click(object sender, EventArgs e)
        {
            doc.Show();
            this.Hide();
        }

        private void btnPagar_Click(object sender, EventArgs e)
        {
            MySqlConnection sqlCon = new MySqlConnection();

            try
            {
                // Obtener valores de los TextBox
                int idCliente = Convert.ToInt32(txtIdCliente.Text);
                float monto = float.Parse(txtMonto.Text);
                string concepto = txtConcepto.Text;
                string formaPago = optEfvo.Checked ? "Efectivo" : "Tarjeta"; // Determinar la forma de pago

                // Aplicar descuento del 10% si es pago en efectivo
                if (optEfvo.Checked)
                {
                    monto *= 0.9f;
                }

                // Construir la consulta SQL de inserción
                string insertQuery = "INSERT INTO pago (NPostu, monto, fecha,  formaPago,concepto) VALUES (@NPostu, @monto, @fecha, @formaPago, @concepto)";

                // Crear la conexión y el comando
                sqlCon = Conexion.getInstancia().CrearConexion();
                MySqlCommand insertCommand = new MySqlCommand(insertQuery, sqlCon);

                // Agregar parámetros
                insertCommand.Parameters.AddWithValue("@NPostu", idCliente);
                insertCommand.Parameters.AddWithValue("@monto", monto);
                insertCommand.Parameters.AddWithValue("@fecha", DateTime.Now); // Puedes ajustar la fecha según tus necesidades
                insertCommand.Parameters.AddWithValue("@formaPago", formaPago); // Agregar la forma de pago
                insertCommand.Parameters.AddWithValue("@concepto", concepto);


                // Abrir la conexión y ejecutar la consulta de inserción
                sqlCon.Open();
                insertCommand.ExecuteNonQuery();

                // Cerrar la conexión
                sqlCon.Close();

                // Mostrar mensaje de éxito
                MessageBox.Show("Pago registrado exitosamente", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Mostrar comprobante
                MostrarComprobante(idCliente, monto, formaPago, concepto);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
            }
        }

        private void MostrarComprobante(int idCliente, float monto, string concepto, string formaPago)
        {
            // Lógica para mostrar el comprobante
            doc.numero_f = ObtenerUltimoIdPago(); // Puedes crear un método para obtener el último ID de pago
            doc.actividad_f = $"Cliente: {idCliente}";
            doc.cliente_f = $"Concepto: {concepto}";
            doc.monto_f = monto;
            doc.fecha_f = DateTime.Now;
            doc.forma_f = formaPago;

            btnComprobante.Enabled = true;
        }

        private int ObtenerUltimoIdPago()
        {
            // Lógica para obtener el último ID de pago desde la base de datos
            // Puedes implementar un método similar al que usaste para insertar datos
            // o utilizar otra lógica según la estructura de tu base de datos.
            // Aquí se devuelve un valor de ejemplo, pero deberías adaptarlo según tu situación.
            return 1;
        }

        private void frmPagar_Load(object sender, EventArgs e)
        {
            // Código de inicialización, si es necesario.
        }


        private void optEfvo_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void optTarj_CheckedChanged(object sender, EventArgs e)
        {


        }

        private void txtMonto_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtConcepto_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void txtIdCliente_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnListaPagos_Click(object sender, EventArgs e)
        {
            frmGrillaPagos pagos = new frmGrillaPagos();
            pagos.Show();
            this.Hide();

        }
    }
}
