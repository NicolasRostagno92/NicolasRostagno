﻿namespace club_deportivo
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox2 = new GroupBox();
            lblIngreso = new Label();
            btnVolver = new Button();
            btnActividades = new Button();
            btnListaSocios = new Button();
            btnPagar = new Button();
            btnInscribir = new Button();
            label1 = new Label();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lblIngreso);
            groupBox2.Controls.Add(btnVolver);
            groupBox2.Controls.Add(btnActividades);
            groupBox2.Controls.Add(btnListaSocios);
            groupBox2.Controls.Add(btnPagar);
            groupBox2.Controls.Add(btnInscribir);
            groupBox2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox2.Location = new Point(80, 110);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(869, 437);
            groupBox2.TabIndex = 0;
            groupBox2.TabStop = false;
            groupBox2.Text = "ELIJA OPCIÓN:";
            // 
            // lblIngreso
            // 
            lblIngreso.AutoSize = true;
            lblIngreso.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lblIngreso.Location = new Point(292, 25);
            lblIngreso.Name = "lblIngreso";
            lblIngreso.Size = new Size(0, 17);
            lblIngreso.TabIndex = 1;
            // 
            // btnVolver
            // 
            btnVolver.Location = new Point(739, 370);
            btnVolver.Name = "btnVolver";
            btnVolver.Size = new Size(93, 37);
            btnVolver.TabIndex = 0;
            btnVolver.Text = "VOLVER";
            btnVolver.UseVisualStyleBackColor = true;
            btnVolver.Click += btnVolver_Click;
            // 
            // btnActividades
            // 
            btnActividades.Location = new Point(509, 257);
            btnActividades.Name = "btnActividades";
            btnActividades.Size = new Size(192, 89);
            btnActividades.TabIndex = 0;
            btnActividades.Text = "ACTIVIDADES DEL CLUB";
            btnActividades.UseVisualStyleBackColor = true;
            btnActividades.Click += btnActividades_Click;
            // 
            // btnListaSocios
            // 
            btnListaSocios.Location = new Point(124, 268);
            btnListaSocios.Name = "btnListaSocios";
            btnListaSocios.Size = new Size(192, 89);
            btnListaSocios.TabIndex = 0;
            btnListaSocios.Text = "LISTA SOCIOS";
            btnListaSocios.UseVisualStyleBackColor = true;
            btnListaSocios.Click += btnListaSocios_Click;
            // 
            // btnPagar
            // 
            btnPagar.Location = new Point(508, 86);
            btnPagar.Name = "btnPagar";
            btnPagar.Size = new Size(192, 89);
            btnPagar.TabIndex = 0;
            btnPagar.Text = "PAGAR CUOTA";
            btnPagar.UseVisualStyleBackColor = true;
            btnPagar.Click += btnPagar_Click;
            // 
            // btnInscribir
            // 
            btnInscribir.Location = new Point(124, 86);
            btnInscribir.Name = "btnInscribir";
            btnInscribir.Size = new Size(192, 89);
            btnInscribir.TabIndex = 0;
            btnInscribir.Text = "INSCRIBIR";
            btnInscribir.UseVisualStyleBackColor = true;
            btnInscribir.Click += btnInscribir_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(340, 52);
            label1.Name = "label1";
            label1.Size = new Size(332, 45);
            label1.TabIndex = 1;
            label1.Text = "OPCIONES DEL CLUB";
            // 
            // frmPrincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1035, 618);
            Controls.Add(label1);
            Controls.Add(groupBox2);
            Name = "frmPrincipal";
            Text = "PAGINA PRINCIPAL:";
            Load += frmPrincipal_Load;
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox2;
        private Button btnListaSocios;
        private Button btnPagar;
        private Button btnInscribir;
        private Button btnVolver;
        private Button btnActividades;
        private Label label1;
        private Label lblIngreso;
    }
}