using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace club_deportivo
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        internal string? rol;
        internal string? usuario;


        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            lblIngreso.Text = "USUARIO: " + usuario + " " + "(" + rol + ")";
        }

        private void btnListaSocios_Click(object sender, EventArgs e)
        {
            frmGrilla grilla = new frmGrilla();
            grilla.Show();
            this.Close();
        }
        private void btnVolver_Click(object sender, EventArgs e)
        {
            frmLogin login = new frmLogin();
            login.Show();
            this.Close();  // Cierra completamente el formulario actual (frmPrincipal)

        }



        private void btnPagarCuota_Click(object sender, EventArgs e)
        {

        }

        private void btnInscribir_Click(object sender, EventArgs e)
        {
            frmInscripcion inscribir = new frmInscripcion();
            inscribir.Show();
            this.Hide();
        }

        private void btnPagar_Click(object sender, EventArgs e)
        {

            frmPagar pagar = new frmPagar();
            pagar.Show();
            this.Hide();

        }

        private void btnActividades_Click(object sender, EventArgs e)
        {
            frmGrillaActividades actividad = new frmGrillaActividades();
            actividad.Show();
            this.Hide();
        }
    }
}
                                                                                                                                                                                                                                                                                                                                                                                                                         